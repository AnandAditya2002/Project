# Sikkim-Bot

Modules Imported:~
1)PyAudio
2)speech_recognition
3)playsound
4)gtts
5)pandas
6)time
7)re
8)os
9)random
